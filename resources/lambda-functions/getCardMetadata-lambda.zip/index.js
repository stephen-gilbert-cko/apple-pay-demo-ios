const https = require('https');

const getCardMetadata = (event) => {
  const data = {
    source: {
      type: "token",
      token: event.token
    },
    format: "card_payouts"
  };

  return new Promise((resolve, reject) => {
    const options = {
      host: process.env.CKO_ENV,
      path: '/metadata/card',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.CKO_API_KEY}`
      }
    };

    const req = https.request(options, (res) => {
      let responseBody = '';

      res.on('data', (chunk) => {
        responseBody += chunk;
      });

      res.on('end', () => {
        const result = {
          statusCode: res.statusCode,
          body: responseBody
        };
        resolve(result);
      });
    });

    req.on('error', (e) => {
      reject(e.message);
    });

    req.write(JSON.stringify(data));
    req.end();
  });
};

exports.handler = async (event) => {
  try {
    const result = await getCardMetadata(event);
    return {
      statusCode: result.statusCode,
      body: result.body
    };
  } catch (err) {
    console.error(`Error doing the request for the event: ${JSON.stringify(event)} => ${err}`);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Internal Server Error' })
    };
  }
};
